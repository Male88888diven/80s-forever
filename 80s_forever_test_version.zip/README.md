80s Forever Testversion
Diese ZIP enthält die kostenlose Website-Testoberfläche.
Nächster Schritt: Hosting und anschließend Stripe/OpenAI verbinden.
